package com.example.scholarshipportal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ScholarshipPortal2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
